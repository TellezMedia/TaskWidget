const { app, BrowserWindow, Tray, Menu, screen, ipcMain, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const appbar = require('./appbar');

const userDataPath = app.getPath('userData');
const tasksFile = path.join(userDataPath, 'tasks.json');
const settingsFile = path.join(userDataPath, 'settings.json');

let mainWindow;
let tray;
let appBarRegistered = false;

// 60px is about 0.625in at standard 96 DPI, just under your original 0.66in floor,
// per your explicit request to size it down from 70px.
const BAR_THICKNESS = 60;
// Left/Right needs more room for readable wrapped text than a thin edge strip allows.
// Fixed at 100px, does not resize based on content.
const SIDE_THICKNESS = 100;
const THEMES = ['navy', 'charcoal', 'slate', 'forest', 'plum'];
const ARCHIVE_LIMIT = 30;
const APPROACH_OPTIONS = [12, 24, 48, 72, 168];

function approachLabel(hours) {
  if (hours === 168) return '1 week';
  if (hours < 24) return `${hours} hours`;
  return `${hours / 24} days`;
}

function thicknessFor(position) {
  return position === 'left' || position === 'right' ? SIDE_THICKNESS : BAR_THICKNESS;
}

function getTargetDisplay() {
  const settings = getSettings();
  if (settings.displayId != null) {
    const found = screen.getAllDisplays().find((d) => d.id === settings.displayId);
    if (found) return found;
  }
  return screen.getPrimaryDisplay();
}

function loadJSON(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (e) {
    return fallback;
  }
}

function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function getSettings() {
  return loadJSON(settingsFile, {
    position: 'top',
    theme: 'navy',
    snapEnabled: false,
    displayId: null,
    approachWindowHours: 48,
  });
}

function saveSettings(settings) {
  saveJSON(settingsFile, settings);
}

function getState() {
  const raw = loadJSON(tasksFile, { tasks: [], archive: [] });
  // Older versions stored tasks.json as a flat array. Keep reading those.
  if (Array.isArray(raw)) {
    return { tasks: raw, archive: [] };
  }
  return { tasks: raw.tasks || [], archive: raw.archive || [] };
}

function saveState(state) {
  saveJSON(tasksFile, state);
}

function archiveTaskById(id, reason) {
  const state = getState();
  const idx = state.tasks.findIndex((t) => t.id === id);
  if (idx === -1) return;

  const [task] = state.tasks.splice(idx, 1);
  state.archive.unshift({ ...task, archivedAt: Date.now(), reason });
  state.archive = state.archive.slice(0, ARCHIVE_LIMIT);
  saveState(state);

  if (mainWindow) mainWindow.webContents.send('tasks-updated', state.tasks);
  if (restorePanelWindow) restorePanelWindow.webContents.send('archive-updated', state.archive);
}

function restoreTaskById(id) {
  const state = getState();
  const idx = state.archive.findIndex((t) => t.id === id);
  if (idx === -1) return;

  const [item] = state.archive.splice(idx, 1);
  const { archivedAt, reason, ...task } = item;
  task.completed = false;
  state.tasks.push(task);
  saveState(state);

  if (mainWindow) mainWindow.webContents.send('tasks-updated', state.tasks);
  if (restorePanelWindow) restorePanelWindow.webContents.send('archive-updated', state.archive);
}

function applySnap(enabled) {
  if (!mainWindow) return;
  const settings = getSettings();
  const display = getTargetDisplay();

  if (enabled) {
    appBarRegistered = appbar.registerAppBar(mainWindow, settings.position, thicknessFor(settings.position), display.workArea, display.scaleFactor);
  } else if (appBarRegistered) {
    appbar.unregisterAppBar(mainWindow);
    appBarRegistered = false;
  }
}

function getBounds(position) {
  const display = getTargetDisplay();
  const { x, y, width, height } = display.workArea;

  switch (position) {
    case 'top':
      return { x, y, width, height: BAR_THICKNESS };
    case 'bottom':
      return { x, y: y + height - BAR_THICKNESS, width, height: BAR_THICKNESS };
    case 'left':
      return { x, y, width: SIDE_THICKNESS, height };
    case 'right':
      return { x: x + width - SIDE_THICKNESS, y, width: SIDE_THICKNESS, height };
    default:
      return { x, y, width, height: BAR_THICKNESS };
  }
}

function createWindow() {
  const settings = getSettings();
  const bounds = getBounds(settings.position);

  mainWindow = new BrowserWindow({
    ...bounds,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    hasShadow: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.setAlwaysOnTop(true, 'screen-saver');
  mainWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  mainWindow.webContents.once('did-finish-load', () => {
    if (settings.snapEnabled) applySnap(true);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

let popupWindow = null;
let editPopupWindow = null;
let restorePanelWindow = null;

function getPopupBounds(position, popupWidth = 280, popupHeight = 470) {
  const display = getTargetDisplay();
  const { x, y, width, height } = display.workArea;
  const thickness = thicknessFor(position);

  switch (position) {
    case 'top':
      return { x: x + 16, y: y + thickness + 8, width: popupWidth, height: popupHeight };
    case 'bottom':
      return { x: x + 16, y: y + height - thickness - popupHeight - 8, width: popupWidth, height: popupHeight };
    case 'left':
      return { x: x + thickness + 8, y: y + 16, width: popupWidth, height: popupHeight };
    case 'right':
      return { x: x + width - thickness - popupWidth - 8, y: y + 16, width: popupWidth, height: popupHeight };
    default:
      return { x: x + 16, y: y + thickness + 8, width: popupWidth, height: popupHeight };
  }
}

function openAddPopup() {
  if (popupWindow) {
    popupWindow.focus();
    return;
  }
  const settings = getSettings();
  const bounds = getPopupBounds(settings.position);

  popupWindow = new BrowserWindow({
    ...bounds,
    frame: false,
    transparent: true,
    resizable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    hasShadow: true,
    webPreferences: {
      preload: path.join(__dirname, 'popup-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  popupWindow.setAlwaysOnTop(true, 'screen-saver');
  popupWindow.loadFile(path.join(__dirname, 'src', 'add-task.html'), {
    query: { theme: settings.theme || 'navy' },
  });

  popupWindow.on('blur', () => {
    if (popupWindow) popupWindow.close();
  });

  popupWindow.on('closed', () => {
    popupWindow = null;
  });
}

function openEditPopup(taskId) {
  if (editPopupWindow) {
    editPopupWindow.focus();
    return;
  }
  const state = getState();
  const task = state.tasks.find((t) => t.id === taskId);
  if (!task) return;

  const settings = getSettings();
  const bounds = getPopupBounds(settings.position);

  editPopupWindow = new BrowserWindow({
    ...bounds,
    frame: false,
    transparent: true,
    resizable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    hasShadow: true,
    webPreferences: {
      preload: path.join(__dirname, 'popup-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  editPopupWindow.setAlwaysOnTop(true, 'screen-saver');
  editPopupWindow.loadFile(path.join(__dirname, 'src', 'edit-task.html'), {
    query: {
      theme: settings.theme || 'navy',
      id: task.id,
      text: task.text,
      due: task.due || '',
      icon: task.icon || 'flag',
    },
  });

  editPopupWindow.on('blur', () => {
    if (editPopupWindow) editPopupWindow.close();
  });

  editPopupWindow.on('closed', () => {
    editPopupWindow = null;
  });
}

function openRestorePanel() {
  if (restorePanelWindow) {
    restorePanelWindow.focus();
    return;
  }
  const settings = getSettings();
  const bounds = getPopupBounds(settings.position, 300, 420);

  restorePanelWindow = new BrowserWindow({
    ...bounds,
    frame: false,
    transparent: true,
    resizable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    hasShadow: true,
    webPreferences: {
      preload: path.join(__dirname, 'popup-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  restorePanelWindow.setAlwaysOnTop(true, 'screen-saver');
  restorePanelWindow.loadFile(path.join(__dirname, 'src', 'restore-panel.html'), {
    query: { theme: settings.theme || 'navy' },
  });

  restorePanelWindow.on('blur', () => {
    if (restorePanelWindow) restorePanelWindow.close();
  });

  restorePanelWindow.on('closed', () => {
    restorePanelWindow = null;
  });
}

function repositionWindow(position) {
  if (!mainWindow) return;
  const bounds = getBounds(position);
  mainWindow.setBounds(bounds);
  mainWindow.webContents.send('orientation-changed', position);

  const settings = getSettings();
  if (settings.snapEnabled) {
    appbar.unregisterAppBar(mainWindow);
    appBarRegistered = false;
    applySnap(true);
  }
}

function buildTrayMenu() {
  const settings = getSettings();

  const positionItem = (label, value) => ({
    label,
    type: 'radio',
    checked: settings.position === value,
    click: () => {
      settings.position = value;
      saveSettings(settings);
      repositionWindow(value);
      buildTrayMenu();
    },
  });

  const themeLabel = (name) => name.charAt(0).toUpperCase() + name.slice(1);

  const themeItem = (value) => ({
    label: themeLabel(value),
    type: 'radio',
    checked: (settings.theme || 'navy') === value,
    click: () => {
      settings.theme = value;
      saveSettings(settings);
      if (mainWindow) mainWindow.webContents.send('theme-changed', value);
      buildTrayMenu();
    },
  });

  const displays = screen.getAllDisplays();
  const primaryId = screen.getPrimaryDisplay().id;
  const effectiveDisplayId = settings.displayId != null ? settings.displayId : primaryId;

  const monitorItem = (display, index) => ({
    label: `Display ${index + 1} (${display.bounds.width}x${display.bounds.height})${display.id === primaryId ? ' - Primary' : ''}`,
    type: 'radio',
    checked: effectiveDisplayId === display.id,
    click: () => {
      settings.displayId = display.id;
      saveSettings(settings);
      repositionWindow(settings.position);
      buildTrayMenu();
    },
  });

  const approachItem = (hours) => ({
    label: approachLabel(hours),
    type: 'radio',
    checked: (settings.approachWindowHours || 48) === hours,
    click: () => {
      settings.approachWindowHours = hours;
      saveSettings(settings);
      if (mainWindow) mainWindow.webContents.send('approach-window-changed', hours);
      buildTrayMenu();
    },
  });

  const contextMenu = Menu.buildFromTemplate([
    {
      label: mainWindow && mainWindow.isVisible() ? 'Hide' : 'Show',
      click: () => {
        if (!mainWindow) return;
        if (mainWindow.isVisible()) {
          mainWindow.hide();
        } else {
          mainWindow.show();
        }
        buildTrayMenu();
      },
    },
    { type: 'separator' },
    { label: 'Position', enabled: false },
    positionItem('Top', 'top'),
    positionItem('Bottom', 'bottom'),
    positionItem('Left', 'left'),
    positionItem('Right', 'right'),
    { type: 'separator' },
    {
      label: 'Theme',
      submenu: THEMES.map(themeItem),
    },
    { type: 'separator' },
    {
      label: 'Approaching Deadline Window',
      submenu: APPROACH_OPTIONS.map(approachItem),
    },
    ...(displays.length > 1
      ? [
          { type: 'separator' },
          {
            label: 'Monitor',
            submenu: displays.map(monitorItem),
          },
        ]
      : []),
    { type: 'separator' },
    {
      label: 'Snap to screen edge (experimental)',
      type: 'checkbox',
      checked: !!settings.snapEnabled,
      click: (menuItem) => {
        settings.snapEnabled = menuItem.checked;
        saveSettings(settings);
        applySnap(settings.snapEnabled);
        buildTrayMenu();
      },
    },
    {
      label: 'Restore reserved screen space',
      click: () => {
        if (mainWindow) appbar.unregisterAppBar(mainWindow);
        appBarRegistered = false;
      },
    },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() },
  ]);

  tray.setContextMenu(contextMenu);
}

function createTray() {
  const iconPath = path.join(__dirname, 'assets', 'icon.png');
  const icon = nativeImage.createFromPath(iconPath);
  tray = new Tray(icon.resize({ width: 16, height: 16 }));
  tray.setToolTip('Task Bar Widget');
  buildTrayMenu();
}

app.whenReady().then(() => {
  createWindow();
  createTray();

  screen.on('display-added', () => {
    buildTrayMenu();
  });

  screen.on('display-removed', (event, oldDisplay) => {
    const settings = getSettings();
    if (settings.displayId === oldDisplay.id) {
      settings.displayId = null;
      saveSettings(settings);
    }
    repositionWindow(getSettings().position);
    buildTrayMenu();
  });
});

app.on('window-all-closed', () => {
  // Intentionally does not quit, the widget lives in the tray
});

app.on('before-quit', () => {
  if (mainWindow && appBarRegistered) {
    appbar.unregisterAppBar(mainWindow);
    appBarRegistered = false;
  }
});

ipcMain.handle('get-tasks', () => getState().tasks);
ipcMain.handle('get-archive', () => getState().archive);
ipcMain.handle('get-orientation', () => getSettings().position);
ipcMain.handle('get-theme', () => getSettings().theme || 'navy');
ipcMain.handle('get-approach-window', () => getSettings().approachWindowHours || 48);
ipcMain.handle('open-add-popup', () => openAddPopup());
ipcMain.handle('open-edit-popup', (event, taskId) => openEditPopup(taskId));
ipcMain.handle('open-restore-panel', () => openRestorePanel());

ipcMain.on('submit-task', (event, task) => {
  const state = getState();
  state.tasks.push({
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    text: task.text,
    due: task.due || null,
    icon: task.icon || 'flag',
    completed: false,
  });
  saveState(state);
  if (mainWindow) mainWindow.webContents.send('tasks-updated', state.tasks);
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) win.close();
});

ipcMain.on('update-task', (event, payload) => {
  const state = getState();
  const idx = state.tasks.findIndex((t) => t.id === payload.id);
  if (idx !== -1) {
    state.tasks[idx] = {
      ...state.tasks[idx],
      text: payload.text,
      due: payload.due || null,
      icon: payload.icon || state.tasks[idx].icon || 'flag',
    };
    saveState(state);
    if (mainWindow) mainWindow.webContents.send('tasks-updated', state.tasks);
  }
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) win.close();
});

ipcMain.on('delete-task', (event, id) => {
  archiveTaskById(id, 'deleted');
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) win.close();
});

ipcMain.on('toggle-complete', (event, id) => {
  const state = getState();
  const task = state.tasks.find((t) => t.id === id);
  if (task) {
    task.completed = !task.completed;
    saveState(state);
  }
});

ipcMain.on('archive-completed', (event, id) => {
  archiveTaskById(id, 'completed');
});

ipcMain.on('restore-task', (event, id) => {
  restoreTaskById(id);
});

ipcMain.on('cancel-popup', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) win.close();
});

ipcMain.on('reorder-tasks', (event, orderedIds) => {
  const state = getState();
  const byId = new Map(state.tasks.map((t) => [t.id, t]));
  const reordered = orderedIds.map((id) => byId.get(id)).filter(Boolean);

  // Safety check: only apply if nothing got lost in translation
  if (reordered.length === state.tasks.length) {
    state.tasks = reordered;
    saveState(state);
    if (mainWindow) mainWindow.webContents.send('tasks-updated', state.tasks);
  }
});
