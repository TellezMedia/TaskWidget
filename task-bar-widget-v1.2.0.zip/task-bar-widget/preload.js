const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getTasks: () => ipcRenderer.invoke('get-tasks'),
  getOrientation: () => ipcRenderer.invoke('get-orientation'),
  getTheme: () => ipcRenderer.invoke('get-theme'),
  getApproachWindow: () => ipcRenderer.invoke('get-approach-window'),
  onOrientationChanged: (callback) =>
    ipcRenderer.on('orientation-changed', (event, position) => callback(position)),
  onThemeChanged: (callback) =>
    ipcRenderer.on('theme-changed', (event, theme) => callback(theme)),
  onApproachWindowChanged: (callback) =>
    ipcRenderer.on('approach-window-changed', (event, hours) => callback(hours)),
  openAddPopup: () => ipcRenderer.invoke('open-add-popup'),
  openEditPopup: (taskId) => ipcRenderer.invoke('open-edit-popup', taskId),
  openRestorePanel: () => ipcRenderer.invoke('open-restore-panel'),
  toggleComplete: (id) => ipcRenderer.send('toggle-complete', id),
  archiveCompleted: (id) => ipcRenderer.send('archive-completed', id),
  reorderTasks: (orderedIds) => ipcRenderer.send('reorder-tasks', orderedIds),
  onTasksUpdated: (callback) =>
    ipcRenderer.on('tasks-updated', (event, tasks) => callback(tasks)),
});
