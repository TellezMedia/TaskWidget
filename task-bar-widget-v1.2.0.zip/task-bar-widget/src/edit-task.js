const params = new URLSearchParams(window.location.search);
const theme = params.get('theme') || 'navy';
document.documentElement.setAttribute('data-theme', theme);

const taskId = params.get('id');
const initialText = params.get('text') || '';
const initialDue = params.get('due') || '';
const initialIcon = params.get('icon') || 'flag';

const taskText = document.getElementById('taskText');
const iconPicker = document.getElementById('iconPicker');
const calLabel = document.getElementById('calLabel');
const calGrid = document.getElementById('calGrid');
const prevMonthBtn = document.getElementById('prevMonth');
const nextMonthBtn = document.getElementById('nextMonth');
const hourSelect = document.getElementById('hourSelect');
const minuteSelect = document.getElementById('minuteSelect');
const ampmSelect = document.getElementById('ampmSelect');
const clearDateBtn = document.getElementById('clearDate');
const cancelBtn = document.getElementById('cancelAdd');
const confirmBtn = document.getElementById('confirmAdd');
const deleteBtn = document.getElementById('deleteTask');

taskText.value = initialText;

const now = new Date();

function daysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}

function formatISODate(y, m, d) {
  return `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

// Parse the existing due date/time (if any) into the picker's initial state
let initYear = now.getFullYear();
let initMonth = now.getMonth();
let initDateStr = null;
let initHour = 9;
let initMinute = '00';
let initAmpm = 'AM';

if (initialDue) {
  const d = new Date(initialDue);
  if (!isNaN(d.getTime())) {
    initYear = d.getFullYear();
    initMonth = d.getMonth();
    initDateStr = formatISODate(initYear, initMonth, d.getDate());

    let h = d.getHours();
    initAmpm = h >= 12 ? 'PM' : 'AM';
    let h12 = h % 12;
    if (h12 === 0) h12 = 12;
    initHour = h12;

    const roundedMinute = Math.round(d.getMinutes() / 5) * 5;
    initMinute = String(roundedMinute % 60).padStart(2, '0');
  }
}

const state = {
  viewYear: initYear,
  viewMonth: initMonth,
  selectedDate: initDateStr,
  selectedIcon: initialIcon,
};

function renderIconPicker() {
  iconPicker.innerHTML = '';
  ICON_ORDER.forEach((name) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'icon-choice';
    if (state.selectedIcon === name) btn.classList.add('selected');
    btn.innerHTML = ICONS[name];
    btn.title = name;
    btn.addEventListener('click', () => {
      state.selectedIcon = name;
      renderIconPicker();
    });
    iconPicker.appendChild(btn);
  });
}

function renderCalendar() {
  calGrid.innerHTML = '';

  const first = new Date(state.viewYear, state.viewMonth, 1);
  const startDay = first.getDay();
  const totalDays = daysInMonth(state.viewYear, state.viewMonth);

  calLabel.textContent = first.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

  for (let i = 0; i < startDay; i++) {
    const blank = document.createElement('div');
    blank.className = 'cal-cell cal-blank';
    calGrid.appendChild(blank);
  }

  const todayStr = now.toDateString();

  for (let d = 1; d <= totalDays; d++) {
    const cell = document.createElement('div');
    cell.className = 'cal-cell';
    cell.textContent = String(d);

    const cellDate = new Date(state.viewYear, state.viewMonth, d);
    const iso = formatISODate(state.viewYear, state.viewMonth, d);

    if (cellDate.toDateString() === todayStr) cell.classList.add('cal-today');
    if (state.selectedDate === iso) cell.classList.add('cal-selected');

    cell.addEventListener('click', () => {
      state.selectedDate = iso;
      renderCalendar();
    });

    calGrid.appendChild(cell);
  }
}

function populateTimeSelects() {
  for (let h = 1; h <= 12; h++) {
    const opt = document.createElement('option');
    opt.value = String(h);
    opt.textContent = String(h);
    hourSelect.appendChild(opt);
  }
  hourSelect.value = String(initHour);

  for (let m = 0; m < 60; m += 5) {
    const opt = document.createElement('option');
    opt.value = String(m).padStart(2, '0');
    opt.textContent = String(m).padStart(2, '0');
    minuteSelect.appendChild(opt);
  }
  minuteSelect.value = initMinute;
  ampmSelect.value = initAmpm;
}

prevMonthBtn.addEventListener('click', () => {
  state.viewMonth -= 1;
  if (state.viewMonth < 0) {
    state.viewMonth = 11;
    state.viewYear -= 1;
  }
  renderCalendar();
});

nextMonthBtn.addEventListener('click', () => {
  state.viewMonth += 1;
  if (state.viewMonth > 11) {
    state.viewMonth = 0;
    state.viewYear += 1;
  }
  renderCalendar();
});

clearDateBtn.addEventListener('click', () => {
  state.selectedDate = null;
  renderCalendar();
});

function to24Hour(hour12, ampm) {
  let h = hour12 % 12;
  if (ampm === 'PM') h += 12;
  return h;
}

function submit() {
  const text = taskText.value.trim();
  if (!text) return;

  let due = null;
  if (state.selectedDate) {
    const h24 = to24Hour(parseInt(hourSelect.value, 10), ampmSelect.value);
    due = `${state.selectedDate}T${String(h24).padStart(2, '0')}:${minuteSelect.value}:00`;
  }

  window.popupApi.updateTask({ id: taskId, text, due, icon: state.selectedIcon });
}

confirmBtn.addEventListener('click', submit);
cancelBtn.addEventListener('click', () => window.popupApi.cancel());

taskText.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') submit();
  if (e.key === 'Escape') window.popupApi.cancel();
});

let deleteArmed = false;
let deleteTimeout = null;

deleteBtn.addEventListener('click', () => {
  if (!deleteArmed) {
    deleteArmed = true;
    deleteBtn.textContent = 'Confirm delete?';
    deleteBtn.classList.add('armed');
    deleteTimeout = setTimeout(() => {
      deleteArmed = false;
      deleteBtn.textContent = 'Delete';
      deleteBtn.classList.remove('armed');
    }, 4000);
  } else {
    clearTimeout(deleteTimeout);
    window.popupApi.deleteTask(taskId);
  }
});

populateTimeSelects();
renderIconPicker();
renderCalendar();
taskText.focus();
