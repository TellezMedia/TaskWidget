const params = new URLSearchParams(window.location.search);
const theme = params.get('theme') || 'navy';
document.documentElement.setAttribute('data-theme', theme);

const restoreList = document.getElementById('restoreList');

function timeAgo(ts) {
  const diffMs = Date.now() - ts;
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function render(archive) {
  restoreList.innerHTML = '';

  if (!archive || !archive.length) {
    const empty = document.createElement('div');
    empty.className = 'restore-empty';
    empty.textContent = 'Nothing here yet.';
    restoreList.appendChild(empty);
    return;
  }

  archive.forEach((item) => {
    const row = document.createElement('div');
    row.className = 'restore-row';

    const iconEl = document.createElement('span');
    iconEl.className = 'restore-icon';
    iconEl.innerHTML = ICONS[item.icon] || ICONS.flag;

    const info = document.createElement('div');
    info.className = 'restore-info';

    const label = document.createElement('span');
    label.className = 'restore-label';
    label.textContent = item.text;

    const meta = document.createElement('span');
    meta.className = 'restore-meta';
    meta.textContent = `${item.reason === 'deleted' ? 'Deleted' : 'Completed'} ${timeAgo(item.archivedAt)}`;

    info.appendChild(label);
    info.appendChild(meta);

    const restoreBtn = document.createElement('button');
    restoreBtn.type = 'button';
    restoreBtn.className = 'restore-btn';
    restoreBtn.textContent = 'Restore';
    restoreBtn.addEventListener('click', () => {
      window.popupApi.restoreTask(item.id);
    });

    row.appendChild(iconEl);
    row.appendChild(info);
    row.appendChild(restoreBtn);
    restoreList.appendChild(row);
  });
}

window.popupApi.getArchive().then(render);
window.popupApi.onArchiveUpdated(render);
