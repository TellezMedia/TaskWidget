const params = new URLSearchParams(window.location.search);
const theme = params.get('theme') || 'navy';
document.documentElement.setAttribute('data-theme', theme);

const taskText = document.getElementById('taskText');
const iconPicker = document.getElementById('iconPicker');
const calLabel = document.getElementById('calLabel');
const calGrid = document.getElementById('calGrid');
const prevMonthBtn = document.getElementById('prevMonth');
const nextMonthBtn = document.getElementById('nextMonth');
const hourSelect = document.getElementById('hourSelect');
const minuteSelect = document.getElementById('minuteSelect');
const ampmSelect = document.getElementById('ampmSelect');
const clearDateBtn = document.getElementById('clearDate');
const cancelBtn = document.getElementById('cancelAdd');
const confirmBtn = document.getElementById('confirmAdd');

const now = new Date();

const state = {
  viewYear: now.getFullYear(),
  viewMonth: now.getMonth(),
  selectedDate: null, // 'YYYY-MM-DD' or null when no due date is set
  selectedIcon: 'flag',
};

function renderIconPicker() {
  iconPicker.innerHTML = '';
  ICON_ORDER.forEach((name) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'icon-choice';
    if (state.selectedIcon === name) btn.classList.add('selected');
    btn.innerHTML = ICONS[name];
    btn.title = name;
    btn.addEventListener('click', () => {
      state.selectedIcon = name;
      renderIconPicker();
    });
    iconPicker.appendChild(btn);
  });
}

function populateTimeSelects() {
  for (let h = 1; h <= 12; h++) {
    const opt = document.createElement('option');
    opt.value = String(h);
    opt.textContent = String(h);
    hourSelect.appendChild(opt);
  }
  hourSelect.value = '9';

  for (let m = 0; m < 60; m += 5) {
    const opt = document.createElement('option');
    opt.value = String(m).padStart(2, '0');
    opt.textContent = String(m).padStart(2, '0');
    minuteSelect.appendChild(opt);
  }
  minuteSelect.value = '00';
}

function daysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}

function formatISODate(y, m, d) {
  return `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

function renderCalendar() {
  calGrid.innerHTML = '';

  const first = new Date(state.viewYear, state.viewMonth, 1);
  const startDay = first.getDay();
  const totalDays = daysInMonth(state.viewYear, state.viewMonth);

  calLabel.textContent = first.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

  for (let i = 0; i < startDay; i++) {
    const blank = document.createElement('div');
    blank.className = 'cal-cell cal-blank';
    calGrid.appendChild(blank);
  }

  const todayStr = now.toDateString();

  for (let d = 1; d <= totalDays; d++) {
    const cell = document.createElement('div');
    cell.className = 'cal-cell';
    cell.textContent = String(d);

    const cellDate = new Date(state.viewYear, state.viewMonth, d);
    const iso = formatISODate(state.viewYear, state.viewMonth, d);

    if (cellDate.toDateString() === todayStr) cell.classList.add('cal-today');
    if (state.selectedDate === iso) cell.classList.add('cal-selected');

    cell.addEventListener('click', () => {
      state.selectedDate = iso;
      renderCalendar();
    });

    calGrid.appendChild(cell);
  }
}

prevMonthBtn.addEventListener('click', () => {
  state.viewMonth -= 1;
  if (state.viewMonth < 0) {
    state.viewMonth = 11;
    state.viewYear -= 1;
  }
  renderCalendar();
});

nextMonthBtn.addEventListener('click', () => {
  state.viewMonth += 1;
  if (state.viewMonth > 11) {
    state.viewMonth = 0;
    state.viewYear += 1;
  }
  renderCalendar();
});

clearDateBtn.addEventListener('click', () => {
  state.selectedDate = null;
  renderCalendar();
});

function to24Hour(hour12, ampm) {
  let h = hour12 % 12;
  if (ampm === 'PM') h += 12;
  return h;
}

function submit() {
  const text = taskText.value.trim();
  if (!text) return;

  let due = null;
  if (state.selectedDate) {
    const h24 = to24Hour(parseInt(hourSelect.value, 10), ampmSelect.value);
    due = `${state.selectedDate}T${String(h24).padStart(2, '0')}:${minuteSelect.value}:00`;
  }

  window.popupApi.submitTask({ text, due, icon: state.selectedIcon });
}

confirmBtn.addEventListener('click', submit);
cancelBtn.addEventListener('click', () => window.popupApi.cancel());

taskText.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') submit();
  if (e.key === 'Escape') window.popupApi.cancel();
});

populateTimeSelects();
renderIconPicker();
renderCalendar();
taskText.focus();
