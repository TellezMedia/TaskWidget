const bar = document.getElementById('bar');
const taskList = document.getElementById('taskList');
const addBtn = document.getElementById('addBtn');
const restoreBtn = document.getElementById('restoreBtn');
const scrollPrevBtn = document.getElementById('scrollPrevBtn');
const scrollNextBtn = document.getElementById('scrollNextBtn');

restoreBtn.innerHTML = ICONS.clock;

let approachingWindowMs = 48 * 60 * 60 * 1000; // updated from settings on init
const FADE_DELAY_MS = 2000;

let tasks = [];

function statusFor(task) {
  if (task.completed) return 'complete';
  if (!task.due) return 'none';
  const dueTime = new Date(task.due).getTime();
  const now = Date.now();
  if (dueTime < now) return 'overdue';
  if (dueTime - now <= approachingWindowMs) return 'approaching';
  return 'none';
}

function formatDue(due) {
  if (!due) return '';
  const d = new Date(due);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) +
    ' ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
}

function render() {
  taskList.innerHTML = '';

  tasks.forEach((task) => {
    const status = statusFor(task);

    const el = document.createElement('div');
    el.className = 'task status-' + status;
    if (task.fading) el.classList.add('fading');

    const indicator = document.createElement('div');
    indicator.className = 'task-indicator';

    const iconEl = document.createElement('span');
    iconEl.className = 'task-icon';
    iconEl.innerHTML = ICONS[task.icon] || ICONS.flag;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = !!task.completed;
    checkbox.addEventListener('change', () => toggleComplete(task.id));

    indicator.appendChild(iconEl);
    indicator.appendChild(checkbox);

    const info = document.createElement('div');
    info.className = 'task-info';
    info.title = 'Click to edit';
    info.addEventListener('click', () => window.api.openEditPopup(task.id));

    const label = document.createElement('span');
    label.className = 'task-label';
    label.textContent = task.text;
    info.appendChild(label);

    if (task.due) {
      const dueEl = document.createElement('span');
      dueEl.className = 'task-due';
      dueEl.textContent = formatDue(task.due);
      info.appendChild(dueEl);
    }

    el.appendChild(indicator);
    el.appendChild(info);

    attachDragHandlers(el, task);

    taskList.appendChild(el);
  });

  requestAnimationFrame(updateScrollArrows);
}

let draggedId = null;

function attachDragHandlers(el, task) {
  el.draggable = true;

  el.addEventListener('dragstart', () => {
    draggedId = task.id;
    el.classList.add('dragging');
  });

  el.addEventListener('dragend', () => {
    draggedId = null;
    el.classList.remove('dragging');
  });

  el.addEventListener('dragover', (e) => {
    e.preventDefault();
    if (draggedId && draggedId !== task.id) el.classList.add('drag-over');
  });

  el.addEventListener('dragleave', () => {
    el.classList.remove('drag-over');
  });

  el.addEventListener('drop', (e) => {
    e.preventDefault();
    el.classList.remove('drag-over');
    if (!draggedId || draggedId === task.id) return;

    const fromIdx = tasks.findIndex((t) => t.id === draggedId);
    const toIdx = tasks.findIndex((t) => t.id === task.id);
    if (fromIdx === -1 || toIdx === -1) return;

    const [moved] = tasks.splice(fromIdx, 1);
    tasks.splice(toIdx, 0, moved);
    render();
    window.api.reorderTasks(tasks.map((t) => t.id));
  });
}

function isHorizontal() {
  return bar.classList.contains('orientation-top') || bar.classList.contains('orientation-bottom');
}

function updateScrollArrows() {
  const horizontal = isHorizontal();
  const scrollPos = horizontal ? taskList.scrollLeft : taskList.scrollTop;
  const size = horizontal ? taskList.clientWidth : taskList.clientHeight;
  const scrollSize = horizontal ? taskList.scrollWidth : taskList.scrollHeight;

  const hasOverflow = scrollSize > size + 1;
  scrollPrevBtn.classList.toggle('visible', hasOverflow);
  scrollNextBtn.classList.toggle('visible', hasOverflow);

  scrollPrevBtn.disabled = scrollPos <= 0;
  scrollNextBtn.disabled = scrollPos + size >= scrollSize - 1;
}

function pageScroll(direction) {
  const horizontal = isHorizontal();
  const amount = (horizontal ? taskList.clientWidth : taskList.clientHeight) * 0.9 * direction;
  taskList.scrollBy({ [horizontal ? 'left' : 'top']: amount, behavior: 'smooth' });
}

scrollPrevBtn.addEventListener('click', () => pageScroll(-1));
scrollNextBtn.addEventListener('click', () => pageScroll(1));
taskList.addEventListener('scroll', updateScrollArrows);
window.addEventListener('resize', updateScrollArrows);

function toggleComplete(id) {
  const task = tasks.find((t) => t.id === id);
  if (!task) return;

  task.completed = !task.completed;
  window.api.toggleComplete(id);

  if (task.completed) {
    render();
    task.fading = true;
    setTimeout(() => {
      render();
      setTimeout(() => {
        window.api.archiveCompleted(id);
      }, 400);
    }, FADE_DELAY_MS);
  } else {
    task.fading = false;
    render();
  }
}

addBtn.addEventListener('click', () => {
  window.api.openAddPopup();
});

restoreBtn.addEventListener('click', () => {
  window.api.openRestorePanel();
});

window.api.onTasksUpdated((updatedTasks) => {
  tasks = updatedTasks;
  render();
});

function applyOrientation(position) {
  bar.className = 'orientation-' + position;
  requestAnimationFrame(updateScrollArrows);
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
}

window.api.onOrientationChanged((position) => applyOrientation(position));
window.api.onThemeChanged((theme) => applyTheme(theme));
window.api.onApproachWindowChanged((hours) => {
  approachingWindowMs = hours * 60 * 60 * 1000;
  render();
});

async function init() {
  tasks = await window.api.getTasks();
  const orientation = await window.api.getOrientation();
  const theme = await window.api.getTheme();
  const approachHours = await window.api.getApproachWindow();
  approachingWindowMs = approachHours * 60 * 60 * 1000;
  applyOrientation(orientation);
  applyTheme(theme);
  render();
}

// Refresh colors periodically so overdue/approaching status updates live
setInterval(render, 60 * 1000);

init();
