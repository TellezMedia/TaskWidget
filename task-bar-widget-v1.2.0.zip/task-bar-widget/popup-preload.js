const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('popupApi', {
  submitTask: (task) => ipcRenderer.send('submit-task', task),
  updateTask: (payload) => ipcRenderer.send('update-task', payload),
  deleteTask: (id) => ipcRenderer.send('delete-task', id),
  restoreTask: (id) => ipcRenderer.send('restore-task', id),
  getArchive: () => ipcRenderer.invoke('get-archive'),
  onArchiveUpdated: (callback) =>
    ipcRenderer.on('archive-updated', (event, archive) => callback(archive)),
  cancel: () => ipcRenderer.send('cancel-popup'),
});
