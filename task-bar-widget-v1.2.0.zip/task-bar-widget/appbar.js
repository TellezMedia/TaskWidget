// Wraps the Windows Shell "AppBar" API (SHAppBarMessage) so the widget can
// reserve a strip of the screen the way the real taskbar does, which makes
// maximized windows and Snap Layouts snap to its edge instead of covering it.
//
// This is intentionally defensive: every native call is wrapped in try/catch
// and failures just disable the feature rather than crashing the app. On any
// non-Windows platform this module is a no-op.

const os = require('os');

const ABM_NEW = 0x00000000;
const ABM_REMOVE = 0x00000001;
const ABM_QUERYPOS = 0x00000002;
const ABM_SETPOS = 0x00000003;

const ABE_LEFT = 0;
const ABE_TOP = 1;
const ABE_RIGHT = 2;
const ABE_BOTTOM = 3;

const EDGE_MAP = { left: ABE_LEFT, top: ABE_TOP, right: ABE_RIGHT, bottom: ABE_BOTTOM };

let koffi = null;
let APPBARDATA = null;
let SHAppBarMessage = null;
let available = false;
let initTried = false;

function init() {
  if (initTried) return available;
  initTried = true;

  if (os.platform() !== 'win32') return false;

  try {
    koffi = require('koffi');
    const shell32 = koffi.load('shell32.dll');

    const RECT = koffi.struct('RECT', {
      left: 'int32',
      top: 'int32',
      right: 'int32',
      bottom: 'int32',
    });

    APPBARDATA = koffi.struct('APPBARDATA', {
      cbSize: 'uint32',
      hWnd: 'uintptr_t',
      uCallbackMessage: 'uint32',
      uEdge: 'uint32',
      rc: RECT,
      lParam: 'intptr_t',
    });

    SHAppBarMessage = shell32.func(
      'SHAppBarMessage',
      'uintptr_t',
      ['uint32', koffi.pointer(APPBARDATA)]
    );

    available = true;
  } catch (e) {
    console.warn('[appbar] native module unavailable, snapping disabled:', e.message);
    available = false;
  }

  return available;
}

function hwndFromWindow(win) {
  const buf = win.getNativeWindowHandle();
  if (buf.length >= 8) return buf.readBigUInt64LE(0);
  return BigInt(buf.readUInt32LE(0));
}

function blankData(hwnd, edge) {
  return {
    cbSize: koffi.sizeof(APPBARDATA),
    hWnd: hwnd,
    uCallbackMessage: 0,
    uEdge: edge !== undefined ? EDGE_MAP[edge] : 0,
    rc: { left: 0, top: 0, right: 0, bottom: 0 },
    lParam: 0,
  };
}

function registerAppBar(win, edge, thickness, screenBounds, scaleFactor) {
  if (!init()) return false;

  try {
    const hwnd = hwndFromWindow(win);
    const data = blankData(hwnd, edge);

    SHAppBarMessage(ABM_NEW, data);

    // SHAppBarMessage expects physical pixels, but Electron's screen module
    // reports DIP (DPI-scaled logical pixels), so we convert here. Skipping
    // this is what causes the reserved region to not match the window's
    // actual on-screen size, showing up as a blank gap or an overlap.
    const factor = scaleFactor || 1;
    const toPx = (v) => Math.round(v * factor);

    const x = toPx(screenBounds.x);
    const y = toPx(screenBounds.y);
    const width = toPx(screenBounds.width);
    const height = toPx(screenBounds.height);
    const t = toPx(thickness);

    if (edge === 'top') {
      data.rc = { left: x, top: y, right: x + width, bottom: y + t };
    } else if (edge === 'bottom') {
      data.rc = { left: x, top: y + height - t, right: x + width, bottom: y + height };
    } else if (edge === 'left') {
      data.rc = { left: x, top: y, right: x + t, bottom: y + height };
    } else if (edge === 'right') {
      data.rc = { left: x + width - t, top: y, right: x + width, bottom: y + height };
    }

    SHAppBarMessage(ABM_QUERYPOS, data);
    SHAppBarMessage(ABM_SETPOS, data);

    return true;
  } catch (e) {
    console.warn('[appbar] failed to register:', e.message);
    return false;
  }
}

function unregisterAppBar(win) {
  if (!available) return;

  try {
    const hwnd = hwndFromWindow(win);
    const data = blankData(hwnd);
    SHAppBarMessage(ABM_REMOVE, data);
  } catch (e) {
    console.warn('[appbar] failed to unregister:', e.message);
  }
}

module.exports = {
  registerAppBar,
  unregisterAppBar,
  isSupported: () => init(),
};
