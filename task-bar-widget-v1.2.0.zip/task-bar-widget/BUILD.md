# Building Task Bar Widget

This covers building the installer from source. If you just want to run the
app, see the prebuilt `Task Bar Widget Setup X.X.X.exe` releases instead.

## Prerequisites

- Windows 10 or 11
- [Node.js](https://nodejs.org) 18 or newer (LTS recommended)
- Windows Developer Mode enabled: Settings > Privacy & security > For
  developers > Developer Mode. This is needed so the build tool can create
  symbolic links without admin rights (see Troubleshooting below).

No compiler or Visual Studio Build Tools are required. The one native
dependency (`koffi`, used for the optional screen-edge snapping feature)
ships prebuilt binaries.

## Setup

Clone the repo and install dependencies:

```
git clone <this-repo-url>
cd task-bar-widget
npm install
```

## Preview without building

```
npm start
```

Launches the widget directly so you can test changes before packaging
anything.

## Build the installer

```
set CSC_IDENTITY_AUTO_DISCOVERY=false
npm run dist
```

The `set` command skips code-signing lookup, which avoids an unnecessary
download of macOS signing tools during a Windows-only build. It only applies
to the current terminal session, so re-run it if you open a new terminal
window.

This produces two files in `dist/`:

- `Task Bar Widget Setup X.X.X.exe`, the installer, this is what you hand out
  to other people
- `Task Bar Widget X.X.X.exe`, a portable standalone exe, useful for quick
  testing without installing

## Troubleshooting

**Build fails with a "Cannot create symbolic link" or winCodeSign error**
This is an electron-builder quirk: it tries to download macOS code-signing
tools even for a Windows-only build, and extracting them needs symlink
permissions a standard account doesn't have. Fix: enable Windows Developer
Mode (see Prerequisites) and make sure you ran the `set
CSC_IDENTITY_AUTO_DISCOVERY=false` command above before `npm run dist`.

**`npm install` blocks Electron's postinstall script**
Recent npm versions may print something like:
```
1 package has install scripts blocked because they are not covered by allowScripts
```
Run the command npm suggests, typically:
```
npm install-scripts approve electron
```
then run `npm install` again.

**Command not found errors when typing the exe path**
Windows splits on spaces in the terminal. Wrap paths with spaces in quotes
(`"dist\Task Bar Widget X.X.X.exe"`), or just double-click the exe from File
Explorer instead.

## Distributing to others

Send only `Task Bar Widget Setup X.X.X.exe`. It's fully self-contained,
recipients need nothing installed beforehand, no Node, no npm.

Since it isn't code-signed, Windows SmartScreen will show a "Windows
protected your PC" warning the first time each person runs it. "More info"
then "Run anyway" clears it. This is expected, not a sign of a problem, it's
worth mentioning to whoever you send it to so they don't assume it's
flagged as malicious.

## Where app data lives

Not in this repo or the installed app folder. Each user's tasks and settings
are stored per-Windows-account at:
```
%APPDATA%\Task Bar Widget\
```
(`tasks.json` and `settings.json`). This is independent of where the app
itself is installed, so reinstalling or moving the app doesn't affect saved
tasks.

## Before building a new version

1. Bump the `version` field in `package.json`
2. Add an entry to `RELEASE_NOTES.md` describing what changed
3. Run the build steps above
