const bar = document.getElementById('bar');
const taskList = document.getElementById('taskList');
const addBtn = document.getElementById('addBtn');

const APPROACHING_WINDOW_MS = 48 * 60 * 60 * 1000; // 48 hours
const FADE_DELAY_MS = 2000;

let tasks = [];

function statusFor(task) {
  if (task.completed) return 'complete';
  if (!task.due) return 'none';
  const dueTime = new Date(task.due).getTime();
  const now = Date.now();
  if (dueTime < now) return 'overdue';
  if (dueTime - now <= APPROACHING_WINDOW_MS) return 'approaching';
  return 'none';
}

function formatDue(due) {
  if (!due) return '';
  const d = new Date(due);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) +
    ' ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
}

function render() {
  taskList.innerHTML = '';

  tasks.forEach((task) => {
    const status = statusFor(task);

    const el = document.createElement('div');
    el.className = 'task status-' + status;
    if (task.fading) el.classList.add('fading');

    const indicator = document.createElement('div');
    indicator.className = 'task-indicator';

    const iconEl = document.createElement('span');
    iconEl.className = 'task-icon';
    iconEl.innerHTML = ICONS[task.icon] || ICONS.flag;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = !!task.completed;
    checkbox.addEventListener('change', () => toggleComplete(task.id));

    indicator.appendChild(iconEl);
    indicator.appendChild(checkbox);

    const info = document.createElement('div');
    info.className = 'task-info';

    const label = document.createElement('span');
    label.className = 'task-label';
    label.textContent = task.text;
    info.appendChild(label);

    if (task.due) {
      const dueEl = document.createElement('span');
      dueEl.className = 'task-due';
      dueEl.textContent = formatDue(task.due);
      info.appendChild(dueEl);
    }

    el.appendChild(indicator);
    el.appendChild(info);

    taskList.appendChild(el);
  });
}

async function persist() {
  await window.api.saveTasks(tasks);
}

function toggleComplete(id) {
  const task = tasks.find((t) => t.id === id);
  if (!task) return;

  task.completed = !task.completed;

  if (task.completed) {
    render();
    persist();
    task.fading = true;
    setTimeout(() => {
      render();
      setTimeout(() => {
        tasks = tasks.filter((t) => t.id !== id);
        persist();
        render();
      }, 400);
    }, FADE_DELAY_MS);
  } else {
    task.fading = false;
    render();
    persist();
  }
}

addBtn.addEventListener('click', () => {
  window.api.openAddPopup();
});

window.api.onTasksUpdated((updatedTasks) => {
  tasks = updatedTasks;
  render();
});

function applyOrientation(position) {
  bar.className = 'orientation-' + position;
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
}

window.api.onOrientationChanged((position) => applyOrientation(position));
window.api.onThemeChanged((theme) => applyTheme(theme));

async function init() {
  tasks = await window.api.getTasks();
  const orientation = await window.api.getOrientation();
  const theme = await window.api.getTheme();
  applyOrientation(orientation);
  applyTheme(theme);
  render();
}

// Refresh colors periodically so overdue/approaching status updates live
setInterval(render, 60 * 1000);

init();
