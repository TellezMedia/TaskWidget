# Task Bar Widget - Release Notes

## v1.0.0

Visual redesign based on your reference image (the icon + divider style desk strip).

**Layout**
- Removed the rounded pill/chip backgrounds, tasks now sit flat on the bar separated by thin divider lines
- Each task shows a small icon on top with the checkbox underneath, and the task name (bold caps) with due date beneath it to the right
- Checkbox still does the completing, same as before, the icon is just visual, it's not clickable
- Status color (red overdue, yellow approaching, green complete) now colors the icon and checkbox area instead of a border

**Icons**
- Pick one of 12 icons when adding a task: flag, star, target, clipboard, check, question mark, calendar, idea, bell, briefcase, bookmark, clock
- Defaults to flag if you don't pick one

**Theme accents**
- Each of the 5 themes (Navy, Charcoal, Slate, Forest, Plum) now has its own accent color used for dividers and the `+` button, so the accent always matches whichever theme you're on rather than a single fixed color

Everything else (position switching, calendar/time picker, experimental screen-edge snapping) is unchanged from v0.3.0.

## v0.3.0 (Beta)

**Snap to screen edge (experimental, off by default)**
- New tray menu toggle, "Snap to screen edge (experimental)"
- When enabled, registers the bar with Windows the same way the real taskbar does, so maximized windows and Snap Layouts snap to its edge instead of covering it
- Off by default because it touches a more sensitive part of Windows than anything else in the app. If it ever behaves oddly (reserved space not releasing, etc), use the new "Restore reserved screen space" tray item to force a cleanup, or just toggle the feature off
- This required calling a native Windows API (SHAppBarMessage) via a small library called koffi. It uses prebuilt binaries, so no compiler or Visual Studio Build Tools are needed on your end, just `npm install` as usual

**Color themes**
- Tray menu now has a Theme submenu: Navy (default), Charcoal, Slate, Forest, Plum
- Status colors (green complete, red overdue, yellow approaching deadline) stay the same across every theme, only the base bar color changes
- Choice is saved and restored on launch, same as Position

**Calendar and time picker**
- The add-task popup's due date field is now a real calendar grid you click instead of typing
- Time is set with hour/minute/AM-PM dropdowns instead of typing digits
- "No due date" button clears the date if you want a task with no deadline
- Popup window grew slightly (280x420) to fit the calendar

## v0.2.1 (Beta)

**Fix**
- Fixed the `+` button doing nothing. The add-task popup was positioned outside the physical bounds of the bar window itself (the bar window is only 70px thin), so it was never actually visible, not a CSS issue
- The popup is now its own small floating window that opens next to the bar, positioned based on your current Top/Bottom/Left/Right setting
- Clicking outside the popup dismisses it, same as most Windows flyouts

No other behavior changes from v0.2.0.

## v0.2.0 (Beta)

**Installer**
- Adds an NSIS installer build (`Task Bar Widget Setup 0.2.0.exe`) alongside the existing portable exe
- Per-user install, no admin rights required
- Installer lets the install directory be changed, offers Desktop and Start Menu shortcuts, and an "launch on finish" checkbox
- Registers a standard uninstaller in Windows "Add or Remove Programs"
- Not code-signed, so Windows SmartScreen will show a warning on first run for each person. "More info" then "Run anyway" gets past it, this is expected and not an error

Everything from v0.1.0 is unchanged otherwise (window behavior, tasks, colors, tray menu).

## v0.1.0 (Beta)

Initial build.

**Window**
- Frameless, always on top, no browser chrome or title bar
- Bar thickness is 70px, about 0.73 inch at standard 96 DPI, inside your requested 0.66 to 0.75in range
- Position choice via tray icon: Top, Bottom, Left, Right, similar to how macOS lets you move the dock
- Top/Bottom span the screen width, tasks lay out horizontally
- Left/Right span the screen height, tasks stack vertically
- Position choice is saved and restored on next launch
- Lives in the system tray, does not appear in the taskbar or Alt+Tab

**Tasks**
- Add tasks with an optional due date/time via the + button
- Checkbox marks a task complete, it turns green, strikes through, then fades and clears after about 2 seconds
- Color coding: green = complete, red = overdue, yellow = due within 48 hours, grey/navy = no urgency
- Colors refresh automatically every minute so overdue/approaching status stays current
- Tasks persist locally as JSON in the app's user data folder, survives restarts

**Not yet built**
- Editing or deleting an individual task before completion (currently: complete to remove, no manual delete)
- Multi-monitor selection (currently always uses the primary display)
- Reordering tasks by drag and drop
- Custom approaching-deadline window (currently fixed at 48 hours)

## Build info
- Version: 0.1.0
- Stack: Electron + vanilla HTML/CSS/JS
- Status: Beta
