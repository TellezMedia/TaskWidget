const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getTasks: () => ipcRenderer.invoke('get-tasks'),
  saveTasks: (tasks) => ipcRenderer.invoke('save-tasks', tasks),
  getOrientation: () => ipcRenderer.invoke('get-orientation'),
  getTheme: () => ipcRenderer.invoke('get-theme'),
  onOrientationChanged: (callback) =>
    ipcRenderer.on('orientation-changed', (event, position) => callback(position)),
  onThemeChanged: (callback) =>
    ipcRenderer.on('theme-changed', (event, theme) => callback(theme)),
  openAddPopup: () => ipcRenderer.invoke('open-add-popup'),
  onTasksUpdated: (callback) =>
    ipcRenderer.on('tasks-updated', (event, tasks) => callback(tasks)),
});
