const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('popupApi', {
  submitTask: (task) => ipcRenderer.send('submit-task', task),
  cancel: () => ipcRenderer.send('cancel-popup'),
});
