# Setup Instructions

This is delivered as source rather than a prebuilt exe, because packaging a genuine
Windows portable exe requires building on a Windows machine (or with Wine), which
isn't reliably available in the sandbox this was built in. The steps below take
about 5 minutes on your Windows machine.

## Requirements
- Node.js 18 or newer installed on Windows (you already use Node 22 for Digital
  TopLoader, that works fine here too)

## 1. Install dependencies
Open a terminal in the unzipped `task-bar-widget` folder and run:

```
npm install
```

This now also installs `koffi`, used for the optional screen-edge snapping
feature. It ships prebuilt binaries, so this should install cleanly without
needing a compiler.

## 2. Try it out (dev mode)
```
npm start
```
This launches the widget immediately so you can see it before packaging anything.

## 3. Build the installer and portable exe
```
npm run dist
```
This creates two files in the `dist` folder:
- `Task Bar Widget Setup 0.2.0.exe`, the installer, this is the one to hand out to your team
- `Task Bar Widget 0.2.0.exe`, a standalone portable exe, useful for quick testing without installing

If the build errors out mentioning a symbolic link or winCodeSign, that's a known
electron-builder quirk unrelated to your code. Enable Windows Developer Mode
(Settings > Privacy & security > For developers > Developer Mode) and, in the
same terminal window, run `set CSC_IDENTITY_AUTO_DISCOVERY=false` before
`npm run dist` again.

## Distributing to your team
Send them `Task Bar Widget Setup 0.2.0.exe`. When they run it:
- Windows SmartScreen will likely show "Windows protected your PC" since it isn't
  code-signed. They'll need to click "More info" then "Run anyway". This is
  expected, not a sign anything is broken.
- The installer asks whether to create Desktop/Start Menu shortcuts and offers
  to launch the app when finished
- No admin rights needed, it installs per-user
- Each person's tasks are local to their own machine, there's no shared list

## 4. Run at Windows startup (optional)
To have it launch automatically:
1. Press `Win + R`, type `shell:startup`, hit Enter
2. Create a shortcut to the exe from step 3 in that folder

## Using it
- Right-click the tray icon (bottom-right of your screen, may be in the hidden
  icons overflow arrow) to change position (Top/Bottom/Left/Right), theme,
  hide/show, or quit
- Click the `+` on the bar to add a task, pick a date from the calendar and a
  time from the dropdowns, or click "No due date" to skip it
- Check a task off to complete it, it will fade out automatically

## About the "Snap to screen edge" toggle
This is new and experimental. It's off by default. If you turn it on and
anything looks off (a strip of screen stays reserved after quitting, windows
not snapping right), use "Restore reserved screen space" in the tray menu,
or just turn the toggle back off. I'd test this yourself for a bit before
relying on it or shipping it to your team.
