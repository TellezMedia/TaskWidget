const { app, BrowserWindow, Tray, Menu, screen, ipcMain, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const appbar = require('./appbar');

const userDataPath = app.getPath('userData');
const tasksFile = path.join(userDataPath, 'tasks.json');
const settingsFile = path.join(userDataPath, 'settings.json');

let mainWindow;
let tray;
let appBarRegistered = false;

// 70px is roughly 0.73in at standard 96 DPI, inside your requested 0.66 to 0.75in range
const BAR_THICKNESS = 70;
// Left/Right needs more room for readable wrapped text than a thin edge strip allows.
// Fixed at 120px, does not resize based on content.
const SIDE_THICKNESS = 120;
const THEMES = ['navy', 'charcoal', 'slate', 'forest', 'plum'];

function thicknessFor(position) {
  return position === 'left' || position === 'right' ? SIDE_THICKNESS : BAR_THICKNESS;
}

function getTargetDisplay() {
  const settings = getSettings();
  if (settings.displayId != null) {
    const found = screen.getAllDisplays().find((d) => d.id === settings.displayId);
    if (found) return found;
  }
  return screen.getPrimaryDisplay();
}

function loadJSON(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (e) {
    return fallback;
  }
}

function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function getSettings() {
  return loadJSON(settingsFile, { position: 'top', theme: 'navy', snapEnabled: false, displayId: null });
}

function saveSettings(settings) {
  saveJSON(settingsFile, settings);
}

function getTasks() {
  return loadJSON(tasksFile, []);
}

function saveTasks(tasks) {
  saveJSON(tasksFile, tasks);
}

function applySnap(enabled) {
  if (!mainWindow) return;
  const settings = getSettings();
  const display = getTargetDisplay();

  if (enabled) {
    appBarRegistered = appbar.registerAppBar(mainWindow, settings.position, thicknessFor(settings.position), display.workArea);
  } else if (appBarRegistered) {
    appbar.unregisterAppBar(mainWindow);
    appBarRegistered = false;
  }
}

function getBounds(position) {
  const display = getTargetDisplay();
  const { x, y, width, height } = display.workArea;

  switch (position) {
    case 'top':
      return { x, y, width, height: BAR_THICKNESS };
    case 'bottom':
      return { x, y: y + height - BAR_THICKNESS, width, height: BAR_THICKNESS };
    case 'left':
      return { x, y, width: SIDE_THICKNESS, height };
    case 'right':
      return { x: x + width - SIDE_THICKNESS, y, width: SIDE_THICKNESS, height };
    default:
      return { x, y, width, height: BAR_THICKNESS };
  }
}

function createWindow() {
  const settings = getSettings();
  const bounds = getBounds(settings.position);

  mainWindow = new BrowserWindow({
    ...bounds,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    hasShadow: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.setAlwaysOnTop(true, 'screen-saver');
  mainWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  mainWindow.webContents.once('did-finish-load', () => {
    if (settings.snapEnabled) applySnap(true);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

let popupWindow = null;

function getPopupBounds(position) {
  const display = getTargetDisplay();
  const { x, y, width, height } = display.workArea;
  const popupWidth = 280;
  const popupHeight = 470;

  switch (position) {
    case 'top':
      return { x: x + 16, y: y + BAR_THICKNESS + 8, width: popupWidth, height: popupHeight };
    case 'bottom':
      return { x: x + 16, y: y + height - BAR_THICKNESS - popupHeight - 8, width: popupWidth, height: popupHeight };
    case 'left':
      return { x: x + SIDE_THICKNESS + 8, y: y + 16, width: popupWidth, height: popupHeight };
    case 'right':
      return { x: x + width - SIDE_THICKNESS - popupWidth - 8, y: y + 16, width: popupWidth, height: popupHeight };
    default:
      return { x: x + 16, y: y + BAR_THICKNESS + 8, width: popupWidth, height: popupHeight };
  }
}

function openAddPopup() {
  if (popupWindow) {
    popupWindow.focus();
    return;
  }
  const settings = getSettings();
  const bounds = getPopupBounds(settings.position);

  popupWindow = new BrowserWindow({
    ...bounds,
    frame: false,
    transparent: true,
    resizable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    hasShadow: true,
    webPreferences: {
      preload: path.join(__dirname, 'popup-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  popupWindow.setAlwaysOnTop(true, 'screen-saver');
  popupWindow.loadFile(path.join(__dirname, 'src', 'add-task.html'), {
    query: { theme: settings.theme || 'navy' },
  });

  popupWindow.on('blur', () => {
    if (popupWindow) popupWindow.close();
  });

  popupWindow.on('closed', () => {
    popupWindow = null;
  });
}

function repositionWindow(position) {
  if (!mainWindow) return;
  const bounds = getBounds(position);
  mainWindow.setBounds(bounds);
  mainWindow.webContents.send('orientation-changed', position);

  const settings = getSettings();
  if (settings.snapEnabled) {
    appbar.unregisterAppBar(mainWindow);
    appBarRegistered = false;
    applySnap(true);
  }
}

function buildTrayMenu() {
  const settings = getSettings();

  const positionItem = (label, value) => ({
    label,
    type: 'radio',
    checked: settings.position === value,
    click: () => {
      settings.position = value;
      saveSettings(settings);
      repositionWindow(value);
      buildTrayMenu();
    },
  });

  const themeLabel = (name) => name.charAt(0).toUpperCase() + name.slice(1);

  const themeItem = (value) => ({
    label: themeLabel(value),
    type: 'radio',
    checked: (settings.theme || 'navy') === value,
    click: () => {
      settings.theme = value;
      saveSettings(settings);
      if (mainWindow) mainWindow.webContents.send('theme-changed', value);
      buildTrayMenu();
    },
  });

  const displays = screen.getAllDisplays();
  const primaryId = screen.getPrimaryDisplay().id;
  const effectiveDisplayId = settings.displayId != null ? settings.displayId : primaryId;

  const monitorItem = (display, index) => ({
    label: `Display ${index + 1} (${display.bounds.width}x${display.bounds.height})${display.id === primaryId ? ' - Primary' : ''}`,
    type: 'radio',
    checked: effectiveDisplayId === display.id,
    click: () => {
      settings.displayId = display.id;
      saveSettings(settings);
      repositionWindow(settings.position);
      buildTrayMenu();
    },
  });

  const contextMenu = Menu.buildFromTemplate([
    {
      label: mainWindow && mainWindow.isVisible() ? 'Hide' : 'Show',
      click: () => {
        if (!mainWindow) return;
        if (mainWindow.isVisible()) {
          mainWindow.hide();
        } else {
          mainWindow.show();
        }
        buildTrayMenu();
      },
    },
    { type: 'separator' },
    { label: 'Position', enabled: false },
    positionItem('Top', 'top'),
    positionItem('Bottom', 'bottom'),
    positionItem('Left', 'left'),
    positionItem('Right', 'right'),
    { type: 'separator' },
    {
      label: 'Theme',
      submenu: THEMES.map(themeItem),
    },
    ...(displays.length > 1
      ? [
          { type: 'separator' },
          {
            label: 'Monitor',
            submenu: displays.map(monitorItem),
          },
        ]
      : []),
    { type: 'separator' },
    {
      label: 'Snap to screen edge (experimental)',
      type: 'checkbox',
      checked: !!settings.snapEnabled,
      click: (menuItem) => {
        settings.snapEnabled = menuItem.checked;
        saveSettings(settings);
        applySnap(settings.snapEnabled);
        buildTrayMenu();
      },
    },
    {
      label: 'Restore reserved screen space',
      click: () => {
        if (mainWindow) appbar.unregisterAppBar(mainWindow);
        appBarRegistered = false;
      },
    },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() },
  ]);

  tray.setContextMenu(contextMenu);
}

function createTray() {
  const iconPath = path.join(__dirname, 'assets', 'icon.png');
  const icon = nativeImage.createFromPath(iconPath);
  tray = new Tray(icon.resize({ width: 16, height: 16 }));
  tray.setToolTip('Task Bar Widget');
  buildTrayMenu();
}

app.whenReady().then(() => {
  createWindow();
  createTray();

  screen.on('display-added', () => {
    buildTrayMenu();
  });

  screen.on('display-removed', (event, oldDisplay) => {
    const settings = getSettings();
    if (settings.displayId === oldDisplay.id) {
      settings.displayId = null;
      saveSettings(settings);
    }
    repositionWindow(getSettings().position);
    buildTrayMenu();
  });
});

app.on('window-all-closed', () => {
  // Intentionally does not quit, the widget lives in the tray
});

app.on('before-quit', () => {
  if (mainWindow && appBarRegistered) {
    appbar.unregisterAppBar(mainWindow);
    appBarRegistered = false;
  }
});

ipcMain.handle('get-tasks', () => getTasks());
ipcMain.handle('save-tasks', (event, tasks) => {
  saveTasks(tasks);
  return true;
});
ipcMain.handle('get-orientation', () => getSettings().position);
ipcMain.handle('get-theme', () => getSettings().theme || 'navy');
ipcMain.handle('open-add-popup', () => openAddPopup());

ipcMain.on('submit-task', (event, task) => {
  const tasks = getTasks();
  tasks.push({
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    text: task.text,
    due: task.due || null,
    icon: task.icon || 'flag',
    completed: false,
  });
  saveTasks(tasks);
  if (mainWindow) mainWindow.webContents.send('tasks-updated', tasks);
  if (popupWindow) popupWindow.close();
});

ipcMain.on('cancel-popup', () => {
  if (popupWindow) popupWindow.close();
});
